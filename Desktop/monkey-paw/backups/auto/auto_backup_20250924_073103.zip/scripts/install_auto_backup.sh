#!/usr/bin/env bash
set -e

echo "Setting up MonkeyPaw Auto-Backup Service..."
echo "This will save your project every 5 minutes automatically."

PROJECT_ROOT="/Users/thomasbrianreynolds/Desktop/monkey-paw"
PLIST_FILE="$PROJECT_ROOT/scripts/com.monkeypaw.autobackup.plist"
LAUNCHAGENTS_DIR="$HOME/Library/LaunchAgents"

# Create LaunchAgents directory if it doesn't exist
mkdir -p "$LAUNCHAGENTS_DIR"

# Copy the plist file to LaunchAgents
cp "$PLIST_FILE" "$LAUNCHAGENTS_DIR/"

# Unload existing service if running
launchctl unload "$LAUNCHAGENTS_DIR/com.monkeypaw.autobackup.plist" 2>/dev/null || true

# Load the service
launchctl load "$LAUNCHAGENTS_DIR/com.monkeypaw.autobackup.plist"

echo "✅ Auto-backup service installed and started!"
echo ""
echo "Your project will now be automatically saved every 5 minutes to:"
echo "   📁 /Users/thomasbrianreynolds/Desktop/monkey-paw/backups/auto/"
echo ""
echo "The service will:"
echo "   • Create timestamped ZIP backups"
echo "   • Auto-commit changes to Git"
echo "   • Keep the last 4 hours of backups (48 files)"
echo "   • Log activity to backups/auto_backup.log"
echo ""
echo "To check service status: launchctl list | grep monkeypaw"
echo "To stop service: launchctl unload ~/Library/LaunchAgents/com.monkeypaw.autobackup.plist"
echo "To restart service: launchctl load ~/Library/LaunchAgents/com.monkeypaw.autobackup.plist"
echo ""
echo "First backup will run in 5 minutes, then every 5 minutes after that."