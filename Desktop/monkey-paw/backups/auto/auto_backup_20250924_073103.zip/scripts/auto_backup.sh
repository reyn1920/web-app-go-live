#!/usr/bin/env bash
# Auto-backup script that runs every 5 minutes
set -e

PROJECT_ROOT="/Users/thomasbrianreynolds/Desktop/monkey-paw"
BACKUP_DIR="$PROJECT_ROOT/backups/auto"
MAX_BACKUPS=48  # Keep last 4 hours of backups (48 * 5min)

cd "$PROJECT_ROOT"

# Create backup directory
mkdir -p "$BACKUP_DIR"

# Generate timestamp
TS=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/auto_backup_$TS.zip"

echo "$(date): Starting auto-backup..."

# Create backup with all important files
zip -r "$BACKUP_FILE" \
    assets \
    backend \
    config \
    dashboard \
    docs \
    tools \
    qa \
    http \
    scripts \
    superpack \
    macpack \
    -x "*/node_modules/*" "*/venv/*" "*/__pycache__/*" "*/.*" "*/backups/*" || true

# Git auto-commit if there are changes
if ! git diff --quiet || ! git diff --cached --quiet; then
    git add -A
    git commit -m "Auto-save: $(date '+%Y-%m-%d %H:%M:%S')" || echo "Nothing to commit"
fi

# Clean up old backups (keep only last MAX_BACKUPS)
cd "$BACKUP_DIR"
ls -t auto_backup_*.zip | tail -n +$((MAX_BACKUPS + 1)) | xargs rm -f 2>/dev/null || true

echo "$(date): Auto-backup completed: $BACKUP_FILE"
echo "Backup size: $(du -h "$BACKUP_FILE" | cut -f1)"