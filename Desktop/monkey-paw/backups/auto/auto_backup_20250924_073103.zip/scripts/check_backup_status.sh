#!/usr/bin/env bash
# Check auto-backup status

PROJECT_ROOT="/Users/thomasbrianreynolds/Desktop/monkey-paw"
BACKUP_DIR="$PROJECT_ROOT/backups/auto"

echo "🔍 MonkeyPaw Auto-Backup Status"
echo "================================"
echo ""

# Check if service is running
if launchctl list | grep -q "com.monkeypaw.autobackup"; then
    echo "✅ Auto-backup service is RUNNING"
else
    echo "❌ Auto-backup service is NOT running"
    echo "   Run: ./scripts/install_auto_backup.sh to start it"
fi

echo ""

# Check recent backups
if [ -d "$BACKUP_DIR" ]; then
    BACKUP_COUNT=$(ls -1 "$BACKUP_DIR"/auto_backup_*.zip 2>/dev/null | wc -l)
    if [ "$BACKUP_COUNT" -gt 0 ]; then
        echo "📦 Recent Backups ($BACKUP_COUNT total):"
        echo "   Latest 5 backups:"
        ls -lt "$BACKUP_DIR"/auto_backup_*.zip 2>/dev/null | head -5 | while read line; do
            echo "   📄 $line"
        done
        
        echo ""
        LATEST_BACKUP=$(ls -t "$BACKUP_DIR"/auto_backup_*.zip 2>/dev/null | head -1)
        if [ -n "$LATEST_BACKUP" ]; then
            BACKUP_TIME=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M:%S" "$LATEST_BACKUP")
            BACKUP_SIZE=$(du -h "$LATEST_BACKUP" | cut -f1)
            echo "🕒 Last backup: $BACKUP_TIME ($BACKUP_SIZE)"
        fi
    else
        echo "⏳ No backups found yet (service may have just started)"
    fi
else
    echo "📁 Backup directory doesn't exist yet"
fi

echo ""

# Check log files
LOG_FILE="$PROJECT_ROOT/backups/auto_backup.log"
ERROR_LOG="$PROJECT_ROOT/backups/auto_backup.error.log"

if [ -f "$LOG_FILE" ]; then
    echo "📋 Recent log entries:"
    tail -5 "$LOG_FILE" | sed 's/^/   /'
else
    echo "📋 No log file found yet"
fi

if [ -f "$ERROR_LOG" ] && [ -s "$ERROR_LOG" ]; then
    echo ""
    echo "⚠️  Recent errors:"
    tail -5 "$ERROR_LOG" | sed 's/^/   /'
fi

echo ""
echo "💾 Total disk usage by backups: $(du -sh "$BACKUP_DIR" 2>/dev/null | cut -f1 || echo "0B")"