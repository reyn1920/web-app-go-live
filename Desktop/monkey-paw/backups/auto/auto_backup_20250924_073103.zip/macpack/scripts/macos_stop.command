#!/bin/zsh
pkill -f 'uvicorn backend.app:app' || true
echo Stopped.
