
#!/bin/zsh
cd "$(dirname "$0")/.."
export $(grep -v '^#' .env.macos | xargs -I {} echo {})
python3 -m pip install --upgrade pip >/dev/null
python3 -m pip install fastapi uvicorn pillow >/dev/null
uvicorn backend.app:app --host "${UVICORN_HOST:-0.0.0.0}" --port "${UVICORN_PORT:-8000}"
