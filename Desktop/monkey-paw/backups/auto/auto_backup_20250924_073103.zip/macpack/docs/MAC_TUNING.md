# Apple Silicon tuning: keep UVICORN_WORKERS=1, use VideoToolbox encoders.
