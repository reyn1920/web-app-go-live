
#!/usr/bin/env bash
set -e
IN="$1"; ASPECT="$2"; OUT="$3"; CODEC="${4:-h264}"
[ -z "$IN" ] && echo "Usage: reframe_ffmpeg_macos.sh in.mp4 9:16 out.mp4 [h264|hevc]" && exit 1
ENC=${FFMPEG_H264_ENCODER:-h264_videotoolbox}; [ "$CODEC" = "hevc" ] && ENC=${FFMPEG_HEVC_ENCODER:-hevc_videotoolbox}
if [ "$ASPECT" = "9:16" ]; then W=1080; H=1920; elif [ "$ASPECT" = "16:9" ]; then W=1920; H=1080; else W=1080; H=1080; fi
ffmpeg -y -i "$IN" -filter_complex "scale=w=$W:h=-2:force_original_aspect_ratio=decrease,pad=$W:$H:(ow-iw)/2:(oh-ih)/2" -c:v "$ENC" -b:v 6000k -profile:v high -pix_fmt yuv420p -c:a aac -ar 48000 -movflags +faststart "$OUT"
echo "Wrote $OUT"
